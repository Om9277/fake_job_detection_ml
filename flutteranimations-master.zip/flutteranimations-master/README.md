# 🚀 Flutter Application Demo 


Hello Folks,

I made this application via Flutter. It consists of minimal animations and attractive widgets.

The main purpose of building this demo was to show actually flutter is all about animation and building a beautiful UI. I have created wave animation, animated slider, flare animation and for those, I used custom Animated builder, Custom Paint, Animated Container, and Flare widget. 

All suggestions are welcomed. Enjoy the app!! 👍


## 📥 Try-It-Out
<img src="https://github.com/rvvarasdiya/flutteranimations/raw/master/App Demo.gif" title="Adhikaar News" alt="Adhikaar News">

## 📱 Take A Tour
<img src="https://github.com/rvvarasdiya/flutteranimations/raw/master/Home Screen.png" title="Adhikaar News" alt="Adhikaar News">
<img src="https://github.com/rvvarasdiya/flutteranimations/raw/master/Sign In.png" title="Adhikaar News" alt="Adhikaar News">
<img src="https://github.com/rvvarasdiya/flutteranimations/raw/master/Sign Up.png" title="Adhikaar News" alt="Adhikaar News">


## 📝 Contact 

rajvarasdiya535@gmail.com
